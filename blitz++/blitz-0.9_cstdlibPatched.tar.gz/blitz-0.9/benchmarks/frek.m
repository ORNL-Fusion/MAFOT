function frek(Mf)
   A = zeros(1,4);
   A = max(Mf);
   A./A(1,3)
   A = Mf(19,:);
   A./A(1,3)

